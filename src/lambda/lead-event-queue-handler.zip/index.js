const AWS = require('aws-sdk');
const ssm = new AWS.SSM({ apiVersion: '2014-11-06' });
// const MauticConnector = require('node-mautic');
const config = {};
const contactType = 'contact';

let ev, cb;

exports.handler = (event, context, callback) => {
  ev = event;
  cb = callback;
  getSsmParameters()
    .then(buildParameters)
    .then(processQueuedEvent)
    .catch((err) =>
      setImmediate(() => {
        console.log('rejecting ' + err);
        throw err;
      })
    );
};

async function processQueuedEvent() {
  return new Promise(function (resolve, reject) {
    const apiUrl = process.env.apiUrl;
    const username = config.username;
    const password = config.password;
    const mauticConnector = new MauticConnector({
        apiUrl: apiUrl,
        username: username,
        password: password,
    });

    const segments = getMappedSegments(mauticConnector);
    const fields = getFields(mauticConnector);

    for (const event of ev.Records) {
      const eventData = JSON.parse(event.body);
      const lead = (await mauticConnector.contacts.getContactByEmailAddress(eventData.email)).data;

    }

    // const campaigns = (await mauticConnector.campaigns.listCampaigns()).campaigns;

    resolve();

  });
}
/**
 * Retrieve named parameters from SSM matching all *_PARAM env vars.
 *
 * @returns {Promise<Object>} Resolves to AWS.Response.data
 */
function getSsmParameters() {
  const params = [];

  for (const [key, value] of Object.entries(process.env)) {
    if (key.indexOf('_PARAM') !== -1) {
      params.push(value);
    }
  }

  return ssm
    .getParameters({
      Names: params,
      WithDecryption: true,
    })
    .promise();
}

/**
 * Store parameter response as config variables.
 *
 * @see config
 *
 * @param {Object} data Result of ssm.getParameters.
 * @returns {Promise}
 */
function buildParameters(data) {
  return new Promise(function (resolve, reject) {
    // push the returned parameter values into a config array
    for (let i = 0; i < data.Parameters.length; i++) {
      for (const [key, value] of Object.entries(process.env)) {
        if (key.indexOf('_PARAM') !== -1) {
          if (data.Parameters[i].Name === value) {
            config[key.substring(0, key.indexOf('_PARAM'))] = data.Parameters[i].Value;
          }
        }
      }
    }
    resolve();
  });
}


/**
 * Get mapped segments object with structure:
 * segment-alias => segment-id
 *
 * @param {MauticConnector} mauticConnector
 * @returns Object
 */
 async function getMappedSegments(mauticConnector) {
  try {
      const mapped = {};
      const res = await mauticConnector.segments.listSegments({search: "is:published", limit: 1000});
      for (const id in res.lists) {
          const segment = res.lists[id];
          if (segment.alias.indexOf('csi-') === 0) {
              mapped[segment.alias] = segment.id;
          }
      }

      return mapped;
  } catch (error) {
      logError(error);
  }
}

/**
*
*
* @param {MauticConnector} mauticConnector
* @returns Array
*/
async function getFields(mauticConnector) {
  try {
      const fields = [];
      const res = await mauticConnector.fields.listContactFields(contactType);
      for (const id in res.fields) {
          const field = res.fields[id];
          fields.push(field.alias);
      }

      return fields;
  } catch (error) {
      logError(error);
  }
}

/**
*
* @param {MauticConnector} mauticConnector
* @returns Object
*/
async function createSegment(mauticConnector, data) {
  try {
      const res = await mauticConnector.segments.createSegment(data); // create segment
      return res;
  } catch (error) {
      logError(error);
  }
}

/**
*
* @param {MauticConnector} mauticConnector
* @returns Object
*/
async function createOrUpdateContact(mauticConnector, email) {
  try {
      const res = await mauticConnector.contacts.getContactByEmailAddress(email); // get contact by email
      if (res.total > 0) {
          const contacts = res.contacts;
          // return first contact
          return contacts[Object.keys(contacts)[0]];
      } else {
          // create contact
          const res = await mauticConnector.contacts.createContact({
              firstname: 'Gjorge',
              lastname: 'Mihailov',
              email: email
          });
          console.log(res);
          return res;
      }
  } catch (error) {
      logError(error);
  }
}

function logError(error) {
  console.log(error);
}
